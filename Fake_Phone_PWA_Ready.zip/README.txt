FAKE PHONE DEMO — PWA PACKAGE

Files:
- index.html
- manifest.json
- sw.js
- qr.png (provided QR image)
- icon-192.png
- icon-512.png

For PWA Builder:
1. Upload/publish this whole folder to a website.
2. Open the website URL in PWABuilder.
3. The manifest and service worker are already included.

Demo-only flow:
- Demo code: DEMO2026
- Demo PIN: 1234

This project is a simulation UI. It does not process real payments.
